# Steam Chat Client (unofficial)

A small Android app (Kotlin + Jetpack Compose) that signs in to Steam and lets you read and send
friend chat messages. It talks only to `api.steampowered.com` using the same public
`IAuthenticationService`, `IFriendsListService` and `IFriendMessagesService` endpoints Steam's own
web chat uses. No API key is needed.

**Status: written but not yet compiled or run.** It was authored in an environment without an
Android SDK or network access, so expect to fix a few compile errors or API response-shape
differences on first build (see "Known gaps").

## Build the APK

### Option A - GitHub Actions (no local setup)
1. Push this folder to a GitHub repo.
2. Open the **Actions** tab, run **Build APK** (it also runs on every push).
3. Download the `steam-chat-client-debug` artifact. It contains `app-debug.apk`.

### Option B - Android Studio
Open this folder, let it sync, then **Build > Build APK(s)**. Output:
`app/build/outputs/apk/debug/app-debug.apk`.

### Option C - command line
Requires JDK 17, the Android SDK (platform 35) and Gradle 8.9+:

    export ANDROID_HOME=/path/to/android-sdk
    gradle :app:assembleDebug

## Install
Copy the APK to your phone, allow "install unknown apps", and open it.

## Features
- Sign in with account name + password (password RSA-encrypted client-side, as Steam requires)
- Steam Guard: email code, mobile authenticator code, or approve-on-phone
- Refresh token stored encrypted with the Android Keystore; password is never stored
- Friend list with online state, one-to-one chat, send and receive (4 s polling)

## Known gaps
- No push notifications / background service (chat only updates while a conversation is open)
- No group chats, emoji/sticker rendering, images, or typing indicators
- `GetPlayerSummaries` with an access token (instead of an API key) and the exact JSON field
  names in `SteamClient.kt` are based on how Steam's web client behaves and need verifying
  against a live account
- Release builds are signed with the debug key; add your own signing config before distributing

## Notes
This is an independent project, not affiliated with or endorsed by Valve. Use it only with your own
account, and keep in mind Steam's Subscriber Agreement.
