package com.example.steamchat

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.example.steamchat.steam.Session

/** Keeps the Steam refresh token encrypted at rest (Android Keystore). The password is never stored. */
class SessionStore(context: Context) {
    private val prefs = EncryptedSharedPreferences.create(
        context,
        "steam_session",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM,
    )

    fun load(): Session? {
        val id = prefs.getLong("steamid", 0L)
        val token = prefs.getString("refresh", null)
        return if (id != 0L && token != null) Session(id, token, null) else null
    }

    fun save(s: Session) {
        prefs.edit().putLong("steamid", s.steamId).putString("refresh", s.refreshToken).apply()
    }

    fun clear() = prefs.edit().clear().apply()
}
