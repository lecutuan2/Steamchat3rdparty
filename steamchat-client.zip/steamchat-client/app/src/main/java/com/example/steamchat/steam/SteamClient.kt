package com.example.steamchat.steam

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.FormBody
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.math.BigInteger
import java.security.KeyFactory
import java.security.spec.RSAPublicKeySpec
import javax.crypto.Cipher

class SteamException(message: String, val httpCode: Int = 0) : Exception(message)

data class Friend(val steamId: Long, val name: String, val avatarUrl: String?, val online: Boolean)
data class ChatMessage(val fromMe: Boolean, val text: String, val timestamp: Long)

/** What the user must do to finish signing in. */
enum class GuardType { NONE, EMAIL_CODE, DEVICE_CODE, DEVICE_CONFIRMATION, UNKNOWN }

data class PendingLogin(
    val clientId: String,
    val requestId: String,
    val steamId: Long,
    val intervalSec: Float,
    val guard: GuardType,
)

data class Session(val steamId: Long, val refreshToken: String, val accessToken: String?)

/**
 * Minimal Steam Web API client (api.steampowered.com). Uses only the public
 * IAuthenticationService / IFriendsListService / IFriendMessagesService endpoints
 * that Steam's own web chat uses. No API key is required; everything goes through
 * the signed-in user's access token.
 */
class SteamClient(private val http: OkHttpClient = OkHttpClient()) {

    private val base = "https://api.steampowered.com"

    @Volatile var session: Session? = null

    // ---------------------------------------------------------------- HTTP

    private suspend fun request(
        iface: String, method: String, version: Int,
        params: Map<String, String> = emptyMap(),
        post: Boolean = false,
        authed: Boolean = false,
        retried: Boolean = false,
    ): JSONObject = withContext(Dispatchers.IO) {
        val all = params.toMutableMap()
        if (authed) all["access_token"] = ensureAccessToken()
        val url = "$base/$iface/$method/v$version/"
        val req = if (post) {
            val body = FormBody.Builder().also { b -> all.forEach { (k, v) -> b.add(k, v) } }.build()
            Request.Builder().url(url).post(body).build()
        } else {
            val u = url.toHttpUrl().newBuilder().also { b -> all.forEach { (k, v) -> b.addQueryParameter(k, v) } }.build()
            Request.Builder().url(u).get().build()
        }
        http.newCall(req).execute().use { resp ->
            if ((resp.code == 401 || resp.code == 403) && authed && !retried) {
                session = session?.copy(accessToken = null)
                return@withContext request(iface, method, version, params, post, authed, retried = true)
            }
            val eresult = resp.header("X-eresult")
            if (!resp.isSuccessful || (eresult != null && eresult != "1")) {
                throw SteamException("Steam error ${resp.code} (eresult=${eresult ?: "?"})", resp.code)
            }
            val text = resp.body?.string().orEmpty()
            if (text.isBlank()) JSONObject() else JSONObject(text).optJSONObject("response") ?: JSONObject()
        }
    }

    // ---------------------------------------------------------------- Login

    suspend fun beginLogin(username: String, password: String): PendingLogin {
        val key = request("IAuthenticationService", "GetPasswordRSAPublicKey", 1, mapOf("account_name" to username))
        val mod = BigInteger(key.getString("publickey_mod"), 16)
        val exp = BigInteger(key.getString("publickey_exp"), 16)
        val timestamp = key.get("timestamp").toString()

        val pub = KeyFactory.getInstance("RSA").generatePublic(RSAPublicKeySpec(mod, exp))
        val cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding").apply { init(Cipher.ENCRYPT_MODE, pub) }
        val encrypted = Base64.encodeToString(cipher.doFinal(password.toByteArray(Charsets.UTF_8)), Base64.NO_WRAP)

        val r = request(
            "IAuthenticationService", "BeginAuthSessionViaCredentials", 1,
            mapOf(
                "account_name" to username,
                "encrypted_password" to encrypted,
                "encryption_timestamp" to timestamp,
                "remember_login" to "true",
                "persistence" to "1",
                "website_id" to "Mobile",
                "device_friendly_name" to "Steam Chat Client (Android)",
            ),
            post = true,
        )
        val confirmations = r.optJSONArray("allowed_confirmations")
        var guard = GuardType.NONE
        if (confirmations != null) {
            for (i in 0 until confirmations.length()) {
                // 1 = none, 2 = email code, 3 = device code, 4 = device confirm, 5 = email confirm
                when (confirmations.getJSONObject(i).optInt("confirmation_type")) {
                    1 -> guard = GuardType.NONE
                    2 -> guard = GuardType.EMAIL_CODE
                    3 -> guard = GuardType.DEVICE_CODE
                    4 -> if (guard != GuardType.DEVICE_CODE) guard = GuardType.DEVICE_CONFIRMATION
                    else -> if (guard == GuardType.NONE) guard = GuardType.UNKNOWN
                }
            }
        }
        return PendingLogin(
            clientId = r.get("client_id").toString(),
            requestId = r.getString("request_id"),
            steamId = r.get("steamid").toString().toLong(),
            intervalSec = r.optDouble("interval", 5.0).toFloat(),
            guard = guard,
        )
    }

    suspend fun submitGuardCode(p: PendingLogin, code: String) {
        val type = if (p.guard == GuardType.EMAIL_CODE) "2" else "3"
        request(
            "IAuthenticationService", "UpdateAuthSessionWithSteamGuardCode", 1,
            mapOf("client_id" to p.clientId, "steamid" to p.steamId.toString(), "code" to code.trim(), "code_type" to type),
            post = true,
        )
    }

    /** Returns a session once Steam has issued tokens, or null if still waiting. */
    suspend fun pollLogin(p: PendingLogin): Session? {
        val r = request(
            "IAuthenticationService", "PollAuthSessionStatus", 1,
            mapOf("client_id" to p.clientId, "request_id" to p.requestId),
            post = true,
        )
        val refresh = r.optString("refresh_token")
        if (refresh.isBlank()) return null
        val s = Session(p.steamId, refresh, r.optString("access_token").ifBlank { null })
        session = s
        return s
    }

    private suspend fun ensureAccessToken(): String {
        val s = session ?: throw SteamException("Not signed in")
        s.accessToken?.let { return it }
        val r = request(
            "IAuthenticationService", "GenerateAccessTokenForApp", 1,
            mapOf("refresh_token" to s.refreshToken, "steamid" to s.steamId.toString()),
            post = true,
        )
        val token = r.optString("access_token")
        if (token.isBlank()) throw SteamException("Session expired - please sign in again")
        session = s.copy(accessToken = token)
        return token
    }

    // ---------------------------------------------------------------- Friends & chat

    suspend fun friends(): List<Friend> {
        val me = session ?: throw SteamException("Not signed in")
        val r = request("IFriendsListService", "GetFriendsList", 1, authed = true)
        val arr = r.optJSONArray("friends") ?: r.optJSONObject("friendslist")?.optJSONArray("friends")
        val ids = buildList {
            if (arr != null) for (i in 0 until arr.length()) {
                val f = arr.getJSONObject(i)
                // relationship 3 = mutual friend
                if (f.optInt("efriendrelationship", f.optInt("relationship", 3)) == 3) {
                    add(f.get("ulfriendid").toString().toLongOrNull() ?: f.get("steamid").toString().toLong())
                }
            }
        }
        if (ids.isEmpty()) return emptyList()

        val out = mutableListOf<Friend>()
        for (chunk in ids.chunked(100)) {
            val s = request(
                "ISteamUser", "GetPlayerSummaries", 2,
                mapOf("steamids" to chunk.joinToString(",")), authed = true,
            )
            val players = s.optJSONArray("players")
            if (players != null) for (i in 0 until players.length()) {
                val p = players.getJSONObject(i)
                out += Friend(
                    steamId = p.getString("steamid").toLong(),
                    name = p.optString("personaname", p.getString("steamid")),
                    avatarUrl = p.optString("avatarfull").ifBlank { null },
                    online = p.optInt("personastate", 0) > 0,
                )
            }
        }
        @Suppress("UNUSED_VARIABLE") val unused = me
        return out.sortedWith(compareByDescending<Friend> { it.online }.thenBy { it.name.lowercase() })
    }

    suspend fun messages(friendId: Long, count: Int = 50): List<ChatMessage> {
        val me = session ?: throw SteamException("Not signed in")
        val r = request(
            "IFriendMessagesService", "GetRecentMessages", 1,
            mapOf(
                "steamid1" to me.steamId.toString(),
                "steamid2" to friendId.toString(),
                "count" to count.toString(),
                "most_recent_conversation" to "false",
                "bbcode_format" to "false",
            ),
            authed = true,
        )
        val myAccountId = me.steamId - STEAM_ID_BASE
        val arr = r.optJSONArray("messages") ?: return emptyList()
        return (0 until arr.length()).map {
            val m = arr.getJSONObject(it)
            ChatMessage(
                fromMe = m.optLong("accountid") == myAccountId,
                text = m.optString("message"),
                timestamp = m.optLong("timestamp"),
            )
        }.sortedBy { it.timestamp }
    }

    suspend fun send(friendId: Long, text: String) {
        request(
            "IFriendMessagesService", "SendMessage", 1,
            mapOf(
                "steamid" to friendId.toString(),
                "chat_entry_type" to "1",
                "message" to text,
                "contains_bbcode" to "false",
                "echo_to_sender" to "false",
                "low_priority" to "false",
                "client_message_id" to System.nanoTime().toString(),
            ),
            post = true, authed = true,
        )
    }

    companion object {
        const val STEAM_ID_BASE = 76561197960265728L
    }
}
