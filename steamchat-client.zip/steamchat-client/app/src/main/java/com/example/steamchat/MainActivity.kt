package com.example.steamchat

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.steamchat.steam.ChatMessage
import com.example.steamchat.steam.Friend
import com.example.steamchat.steam.GuardType

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFF66C0F4), background = Color(0xFF1B2838), surface = Color(0xFF171A21))) {
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    val ui by vm.ui.collectAsStateWithLifecycle()
                    when {
                        !ui.signedIn -> LoginScreen(ui, vm)
                        ui.openFriend != null -> ChatScreen(ui, vm)
                        else -> FriendsScreen(ui, vm)
                    }
                }
            }
        }
    }
}

@Composable
private fun LoginScreen(ui: UiState, vm: AppViewModel) {
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    val pending = ui.pending

    Column(Modifier.fillMaxSize().padding(24.dp).systemBarsPadding(), verticalArrangement = Arrangement.Center) {
        Text("Steam Chat Client", style = MaterialTheme.typography.headlineMedium)
        Text("Unofficial third-party client. Your password is sent only to Steam.", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(24.dp))

        if (pending == null) {
            OutlinedTextField(user, { user = it }, label = { Text("Steam account name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                pass, { pass = it }, label = { Text("Password") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth(),
            )
            Spacer(Modifier.height(16.dp))
            Button({ vm.signIn(user, pass) }, enabled = !ui.busy && user.isNotBlank() && pass.isNotBlank(), modifier = Modifier.fillMaxWidth()) {
                Text("Sign in")
            }
        } else when (pending.guard) {
            GuardType.EMAIL_CODE, GuardType.DEVICE_CODE -> {
                Text(if (pending.guard == GuardType.EMAIL_CODE) "Enter the Steam Guard code sent to your email." else "Enter the code from your Steam Mobile app.")
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(code, { code = it.uppercase() }, label = { Text("Steam Guard code") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(16.dp))
                Button({ vm.submitCode(code) }, enabled = !ui.busy && code.length >= 5, modifier = Modifier.fillMaxWidth()) { Text("Submit code") }
                TextButton({ vm.cancelLogin() }) { Text("Cancel") }
            }
            GuardType.DEVICE_CONFIRMATION -> {
                Text("Approve this sign-in in your Steam Mobile app.")
                Spacer(Modifier.height(16.dp))
                LinearProgressIndicator(Modifier.fillMaxWidth())
                TextButton({ vm.cancelLogin() }) { Text("Cancel") }
            }
            else -> {
                Text("Finishing sign-in...")
                LinearProgressIndicator(Modifier.fillMaxWidth())
            }
        }

        if (ui.busy && pending == null) { Spacer(Modifier.height(16.dp)); LinearProgressIndicator(Modifier.fillMaxWidth()) }
        ui.error?.let { Spacer(Modifier.height(16.dp)); Text(it, color = MaterialTheme.colorScheme.error) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun FriendsScreen(ui: UiState, vm: AppViewModel) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Friends") },
                actions = {
                    IconButton({ vm.refreshFriends() }) { Icon(Icons.Default.Refresh, "Refresh") }
                    IconButton({ vm.signOut() }) { Icon(Icons.AutoMirrored.Filled.Logout, "Sign out") }
                },
            )
        },
    ) { pad ->
        Column(Modifier.padding(pad)) {
            if (ui.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            ui.error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(16.dp).clickable { vm.dismissError() }) }
            LazyColumn {
                items(ui.friends, key = { it.steamId }) { f -> FriendRow(f) { vm.openChat(f) } }
            }
        }
    }
}

@Composable
private fun FriendRow(f: Friend, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(10.dp).clip(CircleShape).background(if (f.online) Color(0xFF57CBDE) else Color.Gray))
        Spacer(Modifier.width(12.dp))
        Text(f.name, style = MaterialTheme.typography.bodyLarge)
    }
    HorizontalDivider()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ChatScreen(ui: UiState, vm: AppViewModel) {
    val friend = ui.openFriend!!
    BackHandler { vm.closeChat() }
    var draft by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    LaunchedEffect(ui.messages.size) { if (ui.messages.isNotEmpty()) listState.animateScrollToItem(ui.messages.lastIndex) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(friend.name) },
                navigationIcon = { IconButton({ vm.closeChat() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } },
            )
        },
        bottomBar = {
            Row(Modifier.fillMaxWidth().navigationBarsPadding().imePadding().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(draft, { draft = it }, placeholder = { Text("Message") }, modifier = Modifier.weight(1f), maxLines = 4)
                IconButton({ vm.send(draft); draft = "" }, enabled = draft.isNotBlank()) { Icon(Icons.AutoMirrored.Filled.Send, "Send") }
            }
        },
    ) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize(), state = listState, contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(ui.messages) { Bubble(it) }
        }
    }
}

@Composable
private fun Bubble(m: ChatMessage) {
    Box(Modifier.fillMaxWidth(), contentAlignment = if (m.fromMe) Alignment.CenterEnd else Alignment.CenterStart) {
        Surface(
            shape = RoundedCornerShape(14.dp),
            color = if (m.fromMe) MaterialTheme.colorScheme.primary.copy(alpha = 0.85f) else Color(0xFF2A475E),
            modifier = Modifier.widthIn(max = 300.dp),
        ) {
            Text(m.text, Modifier.padding(horizontal = 12.dp, vertical = 8.dp), color = if (m.fromMe) Color.Black else Color.White)
        }
    }
}
