package com.example.steamchat

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.steamchat.steam.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class UiState(
    val signedIn: Boolean = false,
    val busy: Boolean = false,
    val error: String? = null,
    val pending: PendingLogin? = null,
    val friends: List<Friend> = emptyList(),
    val openFriend: Friend? = null,
    val messages: List<ChatMessage> = emptyList(),
)

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val client = SteamClient()
    private val store = SessionStore(app)

    private val _ui = MutableStateFlow(UiState())
    val ui: StateFlow<UiState> = _ui.asStateFlow()

    private var chatJob: Job? = null
    private var loginJob: Job? = null

    init {
        store.load()?.let {
            client.session = it
            _ui.update { s -> s.copy(signedIn = true) }
            refreshFriends()
        }
    }

    private fun fail(e: Throwable) = _ui.update { it.copy(busy = false, error = e.message ?: e.toString()) }

    fun signIn(user: String, password: String) {
        _ui.update { it.copy(busy = true, error = null) }
        viewModelScope.launch {
            try {
                val p = client.beginLogin(user.trim(), password)
                _ui.update { it.copy(busy = false, pending = p) }
                if (p.guard == GuardType.NONE || p.guard == GuardType.DEVICE_CONFIRMATION) startPolling(p)
            } catch (e: Exception) { fail(e) }
        }
    }

    fun submitCode(code: String) {
        val p = _ui.value.pending ?: return
        _ui.update { it.copy(busy = true, error = null) }
        viewModelScope.launch {
            try {
                client.submitGuardCode(p, code)
                startPolling(p)
            } catch (e: Exception) { fail(e) }
        }
    }

    private fun startPolling(p: PendingLogin) {
        loginJob?.cancel()
        loginJob = viewModelScope.launch {
            _ui.update { it.copy(busy = true) }
            repeat(120) {
                try {
                    client.pollLogin(p)?.let { s ->
                        store.save(s)
                        _ui.update { it.copy(busy = false, signedIn = true, pending = null) }
                        refreshFriends()
                        return@launch
                    }
                } catch (e: Exception) { fail(e); return@launch }
                delay((p.intervalSec * 1000).toLong().coerceAtLeast(2000))
            }
            _ui.update { it.copy(busy = false, error = "Sign-in timed out") }
        }
    }

    fun cancelLogin() {
        loginJob?.cancel()
        _ui.update { it.copy(pending = null, busy = false, error = null) }
    }

    fun refreshFriends() {
        viewModelScope.launch {
            try {
                _ui.update { it.copy(busy = true, error = null) }
                val f = client.friends()
                _ui.update { it.copy(busy = false, friends = f) }
            } catch (e: Exception) { fail(e) }
        }
    }

    fun openChat(friend: Friend) {
        chatJob?.cancel()
        _ui.update { it.copy(openFriend = friend, messages = emptyList(), error = null) }
        chatJob = viewModelScope.launch {
            while (true) {
                try {
                    val m = client.messages(friend.steamId)
                    _ui.update { it.copy(messages = m) }
                } catch (e: Exception) { _ui.update { it.copy(error = e.message) } }
                delay(4000) // simple polling; replace with a websocket/long-poll if you need push
            }
        }
    }

    fun closeChat() {
        chatJob?.cancel()
        _ui.update { it.copy(openFriend = null, messages = emptyList()) }
    }

    fun send(text: String) {
        val f = _ui.value.openFriend ?: return
        if (text.isBlank()) return
        viewModelScope.launch {
            try {
                client.send(f.steamId, text)
                _ui.update { it.copy(messages = it.messages + ChatMessage(true, text, System.currentTimeMillis() / 1000)) }
            } catch (e: Exception) { _ui.update { it.copy(error = e.message) } }
        }
    }

    fun signOut() {
        chatJob?.cancel(); loginJob?.cancel()
        store.clear(); client.session = null
        _ui.value = UiState()
    }

    fun dismissError() = _ui.update { it.copy(error = null) }
}
